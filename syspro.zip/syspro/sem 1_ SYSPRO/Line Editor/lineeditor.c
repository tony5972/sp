/* Line Editor */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

 struct node
  {
     char l[500];
     struct node *next;
  } *head,*temp,*curr;

  static cnt;

   void create()  //to create a single
    {
      struct node *nw;
      int i;
      nw=(struct node *)malloc(sizeof(struct node));
      //printf("\n In create function");
      gets(nw->l);
      nw->next=NULL;
      if(head==NULL)
      temp=head=nw;
       else
	{
	 curr=nw;
	 temp->next=curr;
	 temp=curr;
	}
   }

 void disp(int s, int e)  //print the lines in between range
      {
       int i;
       curr=head;
       for(i=1;i<s && curr!=NULL;i++,curr=curr->next);
       for(i=s;i<=e && curr!=NULL;i++,curr=curr->next)
	{
	 printf("\n %d.%s",i,curr->l);
	}
      }

 void print() //to print all the lines
	{
	 int i=1;
	 curr=head;
	 while(curr)
	  {
	    printf("\n %d.%s",i,curr->l);
	    curr=curr->next;
	    i++;
	  }
       }

 void del(int pos) //to delete a line
	 {
	  int cnt,i;
	  if(pos==1)
	  {
	    curr=head;
	    head=head->next;
	    free(curr);
	  }
	   else
	   {
	    for(i=1,curr=head;i<pos-1 && curr;i++,curr=curr->next);
	    temp=curr->next;
	    curr->next=temp->next;
	    free(temp);
	   }
	}

 void del1(int s,int e)  //to delete a lines between the ranges
	  {
	    struct node *temp1,temp2;
	    int cnt,i;
	    while(s!=e+1)
	     {
	     if(s==1)
	      {
	      for(i=1,curr=head;i<=e && curr!=NULL;i++,curr=curr->next);
	       {
		temp=head;
		head=head->next;
		free(temp);
	       }
	  }
	    else
	     {
	      for(i=1,curr=head;i<s-1 && curr;i++,curr=curr->next);
	      temp=curr->next;
	      curr->next=temp->next;
	      free(temp);
	    }
	    e--;
	    }//while
       }//del


 
   void save(char s[20])
	      {
	       FILE *fp;
	       fp=fopen(s,"w");
	       curr=head;
	       while(curr)
		{
		fprintf(fp,curr->l);
		curr=curr->next;
	     }
	      fclose(fp);
	    }

    void append() //append a line at the end of the line
	      {
	       temp=head;
	       while(temp->next!=NULL)
		{
		 temp=temp->next;
		}
		 create();
	       }



	   void help()
	 {
	    printf("\n c : To Create a New Line ");
	    printf("\n p : To print all the lines ");
	    printf("\n d : To delete a line d<line no.> .");
	    printf("\n a : To append new line");
	    printf("\n s : To Save all the lines in a File");
	    printf("\n e : To Exit");
	 }

	 void main()
	 {
	  int s,e;
	  char ch,c,l,fname[17],str[50];
	  //clrscr();
	  head=temp=curr=NULL;
	  do
	  {
	     printf("\n $:>");
	     //flushall();
	     scanf("%c",&c);
	      switch(c)
	       {
		case 'c':  //create a new line
		case 'C':    
				create();
				break;
		case 'p':
		case 'P': //print all the lines
				scanf("%c",&l);
				if(l=='\n')
				{
				   print();
				}
				else
				{
				 scanf("%d%d",&s,&e);
				 if(s>0 && e>0 && s<e)
				 disp(s,e);
				 else
				  disp(1,49);
				}
				break;

		case 'd':
		case 'D': //delete a line
				scanf("%d",&s);
				scanf("%c",&l);
				if(l=='\n')
				{
				 del(s);
				}
				else
				{
				 scanf("%d",&e);
				 del1(s,e);
				}
				
		break;

	

		case 's':
		case 'S': //to save a file 
				printf("\n Enter the file Name: ");
				//flushall();
				gets(fname);
				save(fname);
				printf("\n File is Saved Successfully");
				break;





		case 'a':
		case 'A': //append a line at the end
				append();
				break;

		case 'h':
		case 'H':
		case '?':
				help();
				break;

		case 'e':
		case 'E':
				exit(0);
	  
			 default:
				break;
		 
     }
	       }while(1);
          }

