#include<stdio.h>

#include<string.h>
 void main()
{
	char ch,str[20],symb[20];
	int i,j,cstate=0,sym,len,k,snum,st,final[20],transition[20][20],str1[20];
//	clrscr();

	printf("\n Enter the number of state:\n");
	scanf("%d",&st);
	printf("\n Enter the final states:\n");
	for(i=0;i<st;i++)
	{
		printf("\n Is q%d is final? 1/0\n",i);
		scanf("%d",&final[i]);
	}
	printf("\nEnter the number of symbols:\n");
	scanf("%d",&snum);
	for(i=0;i<snum;i++)
	{
		printf("Enter the symbol");
		scanf("%s",&symb[i]);
	}
	for(i=0;i<st;i++)
	{
		for(j=0;j<snum;j++)
		{
			printf("\n Enter the state q%d->%c   ",i,symb[j]);
			scanf("%d",&transition[i][j]);
		}
	}

	printf("\n Enter the string :\n");
	scanf("%s",str);
       //	gets(str);
//	puts(str);
	len=strlen(str);

	printf("\n Length is %d",len);
	printf("\n String is %s",str);

	for(i=0;i<len;i++)
	{
		ch=str[i];
		for(j=0;j<snum;j++)
		{
			if(ch==symb[j])
			{
				sym=j;
				printf("\n str1 i is ...%d\n",i);
			}
		}
		printf("\n sym is %d",sym);
		cstate=transition[cstate][sym];
	}
	printf("\n q%d is the last state..\n",cstate);

	if(final[cstate]==1)
	printf("\n The string is accepted:\n");
	else
	printf("\n The string is rejected...\n");
	printf("\n Transition table is..\n");
	for(i=0;i<st;i++)
	{
		for(j=0;j<snum;j++)
		{
			printf("q%d",transition[i][j]);
		}
		printf("\n");
	}
//getch();
}

